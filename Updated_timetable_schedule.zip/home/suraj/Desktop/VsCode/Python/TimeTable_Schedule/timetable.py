from flask import Blueprint, render_template, redirect, url_for, flash, send_file
from models import generate_valid_timetables, get_all_courses, get_all_professors, get_all_classrooms, get_all_lectures
import pdfkit
import os

timetable_blp = Blueprint('timetable', __name__, static_folder='', template_folder='templates/timetable')

@timetable_blp.route('/generate_timetable', methods=['GET','POST'])
def generate_timetable():
    try:
        # Retrieve the necessary data
        courses = get_all_courses()
        professors = get_all_professors()
        classrooms = get_all_classrooms()

        # Generate timetable combinations
        timetable = generate_valid_timetables()

        # Render the generated timetable to HTML
        rendered = render_template('GenerateTimeTable.html', timetable=timetable)

        # Generate PDF from the rendered HTML
        pdf_path = 'generated_timetable.pdf'
        pdfkit.from_string(rendered, pdf_path)

        flash('Timetable generated successfully!', 'success')
        return redirect(url_for('timetable.download_timetable'))
        #return render_template('download_timetable')

    except Exception as e:
        flash(f'Error generating timetable: {str(e)}', 'danger')
        #return redirect(url_for('timetable.generate_timetable'))
        #return render_template('timetable.generate_timetable')

@timetable_blp.route('/download_timetable')
def download_timetable():
    path = 'generated_timetable.pdf'
    if os.path.exists(path):
        return send_file(path, as_attachment=True)
    else:
        flash('Timetable not found. Please generate the timetable first.', 'danger')
        return redirect(url_for('timetable.generate_timetable'))


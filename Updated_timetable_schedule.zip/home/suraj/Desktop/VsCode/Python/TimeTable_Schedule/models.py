#from app import mysql
#from flask import current_app
#from TimeTable_Schedule import mysql 

# Utility function to add a professor
def add_professor(professor_id, name):
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()

    query = "INSERT INTO professors (professor_id, name) VALUES (%s, %s)"
    cursor.execute(query, (professor_id, name))
    conn.commit()
    cursor.close()


# Utility function to get all professors
def get_all_professors():
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()
    query = "SELECT * FROM professors"
    cursor.execute(query)
    professors = cursor.fetchall()
    cursor.close()
    return professors

# Utility function to add a course
def add_course(course_number, course_name, max_numb_students):
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()
    query = "INSERT INTO courses (course_number, course_name, max_numb_students) VALUES (%s, %s, %s)"
    cursor.execute(query, (course_number, course_name, max_numb_students))
    conn.commit()
    cursor.close()

# Utility function to get all courses
def get_all_courses():
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()
    query = "SELECT * FROM courses"
    cursor.execute(query)
    courses = cursor.fetchall()
    cursor.close()
    return courses



# Utility function to associate professors with a course
def add_professors_to_course(course_id, professor_ids):
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()

    query = "INSERT INTO course_professor (course_id, professor_id) VALUES (%s, %s)"
    for professor_id in professor_ids:
        cursor.execute(query, (course_id, professor_id))
    conn.commit()
    cursor.close()



#Utility Function to add add Lecture.
def add_lecture(course_id,classroom_id, time_slot, day_of_week):
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()
    query = "INSERT INTO lectures (course_id,classroom_id, time_slot, day_of_week) VALUES (%s, %s, %s, %s)"
    cursor.execute(query, (course_id,classroom_id, time_slot, day_of_week))
    conn.commit()
    cursor.close()



def get_all_lectures():
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()

    query = """
    SELECT l.lecture_id, c.course_name,cl.classroom_name, l.time_slot, l.day_of_week
    FROM lectures l
    JOIN courses c ON l.course_id = c.course_id
    JOIN classrooms cl ON l.classroom_id = cl.classroom_id 
    """
    cursor.execute(query)
    lectures = cursor.fetchall()

    cursor.close()
    return lectures



def add_classroom(classroom_name):
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()
    query = "INSERT INTO classrooms (classroom_name) VALUES (%s)"
    cursor.execute(query, (classroom_name,))
    conn.commit()
    cursor.close()

def get_all_classrooms():
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()
    query = "SELECT classroom_id, classroom_name,classroom_capacity FROM classrooms"
    cursor.execute(query)
    classrooms = cursor.fetchall()
    cursor.close()
    return classrooms


# Function to create tables
def create_tables():
    from app import mysql
    conn = mysql.connection
    cursor = conn.cursor()
    
    create_query = '''
     CREATE TABLE IF NOT EXISTS professors (
        id INT AUTO_INCREMENT PRIMARY KEY,
        uid VARCHAR(6) NOT NULL,
        name VARCHAR(25) NOT NULL
    )
    '''     
    
    cursor.execute(create_query)
    mysql.connection.commit()
    
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS courses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        course_number VARCHAR(5) NOT NULL,
        course_name VARCHAR(40) NOT NULL,
        max_numb_students INT NOT NULL
    )
    """)
    conn.commit()
    cursor.close()






# Timetable generation logic
def generate_timetable_combinations():
    courses = get_all_courses()
    professors = get_all_professors()
    timeslots = ['9:30 - 10:30', '10:30 - 11:30', '11:30 - 12:30', '12:30 - 1:30', '2:30 - 3:30', '3:30 - 4:30', '4:30 - 5:30']
    days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    classrooms = get_all_classrooms()

    combinations = []

    for day in days_of_week:
        for timeslot in timeslots:
            for classroom in classrooms:
                for course in courses:
                    for professor in professors:
                        combinations.append({
                            'course': course,
                            'professor': professor,
                            'classroom': classroom,
                            'time_slot': timeslot,
                            'day_of_week': day
                        })

    return combinations

def is_conflict(timetable, entry):
    for scheduled in timetable:
        if scheduled['time_slot'] == entry['time_slot'] and scheduled['day_of_week'] == entry['day_of_week']:
            if scheduled['classroom']['classroom_id'] == entry['classroom']['classroom_id']:
                return True
            if scheduled['professor']['professor_id'] == entry['professor']['professor_id']:
                return True
    return False

def generate_valid_timetables():
    combinations = generate_timetable_combinations()
    timetable = []

    for entry in combinations:
        if not is_conflict(timetable, entry):
            timetable.append(entry)
            add_lecture(
                entry['course']['course_id'],
                entry['classroom']['classroom_id'],
                entry['time_slot'],
                entry['day_of_week']
            )
            if len(timetable) >= len(combinations):
                break

    return timetable



